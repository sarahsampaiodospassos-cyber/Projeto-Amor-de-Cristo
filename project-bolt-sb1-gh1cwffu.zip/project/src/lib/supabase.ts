import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type LetterType = 'help' | 'motivation' | 'prayer';

export interface PrayerLetter {
  id: string;
  name: string;
  email: string | null;
  letter_type: LetterType;
  message: string;
  created_at: string;
}
