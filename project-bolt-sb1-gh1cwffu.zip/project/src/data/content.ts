export interface Story {
  id: string;
  name: string;
  title: string;
  excerpt: string;
  image: string;
  tag: string;
}

export const stories: Story[] = [
  {
    id: '1',
    name: 'Maria e João',
    title: 'Uma casa para recomeçar',
    excerpt:
      'Depois de anos morando em uma construção improvisada, a família recebeu a chave de uma casa própria. Hoje, as crianças têm um teto seguro e um quintal para brincar.',
    image:
      'https://images.pexels.com/photos/7551587/pexels-photo-7551587.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    tag: 'Casa própria',
  },
  {
    id: '2',
    name: 'Dona Rita',
    title: 'A cesta que trouxe dignidade',
    excerpt:
      'Viúva e sem apoio, Dona Rita encontrou na cesta básica mensal não apenas alimento, mas a certeza de que não estava sozinha. Hoje ela ajuda a distribuir cestas a outros vizinhos.',
    image:
      'https://images.pexels.com/photos/6646880/pexels-photo-6646880.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    tag: 'Cesta básica',
  },
  {
    id: '3',
    name: 'Família Souza',
    title: 'Do desemprego à cozinha comunitária',
    excerpt:
      'Com o apoio da associação, Sr. Souza aprendeu a cozinhar e hoje lidera a cozinha comunitária do bairro, servindo dezenas de refeições por dia.',
    image:
      'https://images.pexels.com/photos/6647063/pexels-photo-6647063.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    tag: 'Associação social',
  },
];

export interface SocialAction {
  id: string;
  icon: string;
  title: string;
  description: string;
}

export const socialActions: SocialAction[] = [
  {
    id: 'sewing',
    icon: 'Scissors',
    title: 'Oficina de costura',
    description:
      'Mulheres da comunidade aprendem corte e costura, gerando renda própria e fortalecendo a autoestima.',
  },
  {
    id: 'literacy',
    icon: 'BookOpen',
    title: 'Alfabetização de adultos',
    description:
      'Aulas gratuitas para jovens e adultos que não tiveram acesso à escola, abrindo novas portas.',
  },
  {
    id: 'community-garden',
    icon: 'Sprout',
    title: 'Horta comunitária',
    description:
      'Cultivo de hortaliças orgânicas que abastecem a cozinha e geram excedente para venda.',
  },
  {
    id: 'music',
    icon: 'Music',
    title: 'Aulas de música',
    description:
      'Crianças e adolescentes descobrem o universo da música, afastando-se da vulnerabilidade social.',
  },
];
