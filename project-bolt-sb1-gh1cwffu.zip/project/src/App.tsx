import { Navbar } from '@/components/Navbar';
import { Hero } from '@/components/Hero';
import { StorySection } from '@/components/StorySection';
import { DonationSection } from '@/components/DonationSection';
import { LettersSection } from '@/components/LettersSection';
import { StoriesSection } from '@/components/StoriesSection';
import { ActionsSection } from '@/components/ActionsSection';
import { EasterSection } from '@/components/EasterSection';
import { Footer } from '@/components/Footer';

function App() {
  return (
    <div className="min-h-screen overflow-x-hidden bg-white">
      <Navbar />
      <main>
        <Hero />
        <StorySection />
        <DonationSection />
        <LettersSection />
        <StoriesSection />
        <ActionsSection />
        <EasterSection />
      </main>
      <Footer />
    </div>
  );
}

export default App;
