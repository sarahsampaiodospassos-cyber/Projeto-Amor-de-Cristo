import { Scissors, BookOpen, Sprout, Music, type LucideIcon } from 'lucide-react';
import { socialActions } from '@/data/content';
import { useReveal } from '@/hooks/useReveal';

const iconMap: Record<string, LucideIcon> = {
  Scissors,
  BookOpen,
  Sprout,
  Music,
};

export function ActionsSection() {
  const { ref, inView } = useReveal();

  return (
    <section id="acoes" className="bg-sand-100 py-20 lg:py-32">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div
          ref={ref}
          className={`reveal ${inView ? 'in-view' : ''} mx-auto max-w-2xl text-center`}
        >
          <span className="text-sm font-semibold uppercase tracking-wider text-coral-600">
            Associações Sociais
          </span>
          <h2 className="mt-3 font-heading text-[2rem] font-bold text-primary-900 sm:text-4xl">
            Ações que vão além da casa e da cesta
          </h2>
          <p className="mt-4 text-base leading-relaxed text-primary-700 sm:mt-5 sm:text-lg">
            Além da construção de casas e da distribuição de cestas básicas,
            mantemos associações sociais que promovem dignidade, geração de renda
            e desenvolvimento comunitário.
          </p>
        </div>

        <div className="mt-10 grid gap-4 sm:mt-16 sm:grid-cols-2 sm:gap-6 lg:grid-cols-4">
          {socialActions.map((a, i) => {
            const Icon = iconMap[a.icon];
            return <ActionCard key={a.id} action={a} Icon={Icon} index={i} />;
          })}
        </div>
      </div>
    </section>
  );
}

function ActionCard({
  action,
  Icon,
  index,
}: {
  action: (typeof socialActions)[number];
  Icon: LucideIcon;
  index: number;
}) {
  const { ref, inView } = useReveal();

  return (
    <div
      ref={ref}
      className={`reveal ${inView ? 'in-view' : ''} group rounded-2xl bg-white p-6 shadow-md shadow-primary-900/5 transition-all duration-300 hover:-translate-y-2 hover:shadow-xl hover:shadow-primary-900/10 sm:p-7`}
      style={{ animationDelay: `${index * 100}ms` }}
    >
      <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary-50 text-primary-600 transition-colors group-hover:bg-coral-500 group-hover:text-white">
        <Icon className="h-7 w-7" />
      </div>
      <h3 className="font-heading text-lg font-bold text-primary-900">
        {action.title}
      </h3>
      <p className="mt-3 text-sm leading-relaxed text-primary-600">
        {action.description}
      </p>
    </div>
  );
}
