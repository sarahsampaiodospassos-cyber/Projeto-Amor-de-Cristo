import { Heart, Home, Gift, ArrowDown } from 'lucide-react';

export function Hero() {
  return (
    <section
      id="inicio"
      className="relative flex min-h-screen items-center overflow-hidden bg-primary-950"
    >
      <div className="absolute inset-0">
        <img
          src="https://images.pexels.com/photos/6646878/pexels-photo-6646878.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
          alt="Voluntários distribuindo alimentos"
          className="h-full w-full object-cover opacity-30"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-primary-950/80 via-primary-900/70 to-primary-950" />
      </div>

      <div className="relative mx-auto max-w-7xl px-5 pt-28 pb-20 lg:px-8 lg:pt-24">
        <div className="max-w-3xl">
          <span className="inline-flex items-center gap-2 rounded-full border border-coral-400/30 bg-coral-500/10 px-4 py-1.5 text-sm font-medium text-coral-300 animate-fade-in">
            <Heart className="h-4 w-4" fill="currentColor" />
            Projeto Amor de Cristo
          </span>

          <h1 className="mt-5 font-heading text-[2rem] font-extrabold leading-tight text-white text-balance sm:mt-6 sm:text-5xl lg:text-6xl animate-fade-up">
            Levando amor, esperança e
            <span className="text-coral-400"> dignidade</span> a quem mais
            precisa
          </h1>

          <p className="mt-5 max-w-2xl text-base leading-relaxed text-primary-200 animate-fade-up [animation-delay:150ms] opacity-0 sm:mt-6 sm:text-lg">
            Construímos casas, distribuímos cestas básicas e realizamos ações
            sociais que transformam histórias. Tudo feito com fé e com a força de
            pessoas que acreditam no próximo.
          </p>

          <div className="mt-8 flex flex-col gap-3 animate-fade-up [animation-delay:300ms] opacity-0 sm:mt-10 sm:flex-row sm:flex-wrap sm:gap-4">
            <a
              href="#doar"
              className="inline-flex items-center gap-2 rounded-full bg-coral-500 px-7 py-3.5 text-base font-semibold text-white shadow-xl shadow-coral-600/30 transition-all hover:bg-coral-600 hover:scale-105"
            >
              <Heart className="h-5 w-5" fill="white" />
              Fazer uma Doação
            </a>
            <a
              href="#historia"
              className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/5 px-7 py-3.5 text-base font-semibold text-white backdrop-blur-sm transition-all hover:bg-white/15"
            >
              Conhecer o Projeto
            </a>
          </div>

          <div className="mt-12 grid grid-cols-3 gap-2 max-w-lg animate-fade-up [animation-delay:450ms] opacity-0 sm:mt-16 sm:gap-8">
            <Stat icon={<Home className="h-5 w-5" />} value="50+" label="Casas entregues" />
            <Stat icon={<Gift className="h-5 w-5" />} value="2.000+" label="Cestas distribuídas" />
            <Stat icon={<Heart className="h-5 w-5" />} value="300+" label="Vidas tocadas" />
          </div>
        </div>
      </div>

      <a
        href="#historia"
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-white/60 transition-colors hover:text-white animate-float"
        aria-label="Rolar para baixo"
      >
        <ArrowDown className="h-6 w-6" />
      </a>
    </section>
  );
}

function Stat({
  icon,
  value,
  label,
}: {
  icon: React.ReactNode;
  value: string;
  label: string;
}) {
  return (
    <div className="text-center">
      <div className="mx-auto mb-2 flex h-10 w-10 items-center justify-center rounded-full bg-coral-500/20 text-coral-300">
        {icon}
      </div>
      <div className="font-heading text-xl font-bold text-white sm:text-2xl">{value}</div>
      <div className="mt-1 text-[0.65rem] leading-tight text-primary-300 sm:text-xs">{label}</div>
    </div>
  );
}
