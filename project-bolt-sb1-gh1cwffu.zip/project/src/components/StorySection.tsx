import { useReveal } from '@/hooks/useReveal';

const storyBlocks = [
  {
    label: 'A Semente',
    title: 'O início com o Sol Alegria',
    text: 'Tudo começou na Igreja Adventista do Sétimo Dia com o projeto Sol Alegria, voltado para o atendimento de crianças da comunidade. Com o apoio voluntário do pessoal da Igreja Central de Cuiabá, o espaço oferecia refeições, apoio na alfabetização e o ensino da Palavra de Deus. Ali, no contato diário com as famílias, aprendemos que cuidar do espírito e do corpo andam lado a lado.',
  },
  {
    label: 'O Despertar',
    title: 'A primeira reforma que mudou vidas',
    text: 'O grande divisor de águas veio quando o pessoal da Central chamou o seu Erivaldo para realizar algumas ampliações na casa de uma das crianças atendidas. Ao chegar ao local, vendo a situação precária da família, o trabalho foi além do combinado: realizou-se uma grande reforma e uma limpeza completa. Naquele momento, ficou claro o nosso propósito de vida: reformar e construir lares dignos para quem mais precisa.',
  },
  {
    label: 'A União e a Fé',
    title: 'Superando o impossível',
    text: 'Nos primeiros anos, as obras eram feitas de forma simples e discreta, sem qualquer intenção de divulgação — razão pela qual as primeiras casas não têm registros fotográficos. Pouco tempo depois, o irmão Edivaldo juntou-se ao Erivaldo nessa missão. Juntos, abraçaram desafios que pareciam inalcançáveis aos olhos humanos, mas guiados pela certeza de que o amor ao próximo supera qualquer obstáculo.',
  },
  {
    label: 'Nosso Objetivo',
    title: 'Por que “Amor de Cristo”?',
    text: 'O nome do projeto traduz a nossa razão de existir: servir como Jesus serviu. O nosso objetivo não é apenas erguer paredes, mas levar esperança, dignidade e apoio real a famílias que precisam de um recomeço. Hoje, o projeto continua firme nessa missão, mantido unicamente pelo amparo de Deus, pela dedicação de voluntários e pela doação generosa de pessoas que acreditam que a solidariedade e o amor prático têm o poder de transformar vidas.',
  },
];

export function StorySection() {
  const { ref, inView } = useReveal();

  return (
    <section id="historia" className="bg-sand-50 py-20 lg:py-32">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div ref={ref} className={`reveal ${inView ? 'in-view' : ''} max-w-3xl`}>
          <span className="text-sm font-semibold uppercase tracking-wider text-coral-600">
            Nossa História
          </span>
          <h2 className="mt-3 font-heading text-[2rem] font-bold text-primary-900 sm:text-4xl">
            Como tudo começou (e como seguimos de pé)
          </h2>
          <p className="mt-4 text-base leading-relaxed text-primary-700 sm:mt-5 sm:text-lg">
            O Projeto Amor de Cristo nasceu de um gesto simples: a vontade de
            estender a mão a quem precisava com o pouco que tínhamos nas mãos. Mas,
            acima de tudo, nasceu do desejo de colocar em prática o verdadeiro amor
            de Cristo — aquele que não apenas observa, mas se compadece, acolhe e
            transforma a realidade do outro.
          </p>
        </div>

        <div className="mt-12 max-w-4xl space-y-8 sm:mt-16 sm:space-y-10">
          {storyBlocks.map((block, index) => (
            <StoryBlock key={block.label} block={block} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}

function StoryBlock({
  block,
  index,
}: {
  block: (typeof storyBlocks)[number];
  index: number;
}) {
  const { ref, inView } = useReveal();

  return (
    <article
      ref={ref}
      className={`reveal ${inView ? 'in-view' : ''} relative border-l-2 border-primary-200 pl-5 sm:pl-8`}
      style={{ animationDelay: `${index * 100}ms` }}
    >
      <span className="text-sm font-semibold uppercase tracking-wider text-coral-600">
        {block.label}
      </span>
      <h3 className="mt-2 font-heading text-xl font-bold text-primary-900 sm:text-2xl">
        {block.title}
      </h3>
      <p className="mt-3 text-base leading-relaxed text-primary-700 sm:text-lg">
        {block.text}
      </p>
    </article>
  );
}
