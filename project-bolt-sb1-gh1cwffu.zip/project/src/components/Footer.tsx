export function Footer() {
  return (
    <footer className="bg-primary-950 py-12 sm:py-14">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="flex flex-col items-center text-center">
          <div className="overflow-hidden rounded-2xl bg-white px-3 py-2 shadow-lg shadow-primary-950/30">
            <img
              src="/image.png"
              alt="Projeto Amor de Cristo — Organização Social"
              className="h-24 w-56 object-contain sm:h-28 sm:w-64"
            />
          </div>

          <p className="mt-5 max-w-md text-sm leading-relaxed text-primary-300">
            Levando amor, esperança e dignidade a quem mais precisa. Construído
            com fé e pela força da comunidade.
          </p>

          <div className="mt-8 flex flex-col items-center gap-3 text-sm text-primary-300 sm:flex-wrap sm:flex-row sm:justify-center sm:gap-x-6 sm:gap-y-2">
            <a href="#historia" className="hover:text-coral-300 transition-colors">Nossa História</a>
            <a href="#doar" className="hover:text-coral-300 transition-colors">Doações</a>
            <a href="#cartas" className="hover:text-coral-300 transition-colors">Cartas & Orações</a>
            <a href="#historias" className="hover:text-coral-300 transition-colors">Vidas Transformadas</a>
            <a href="#acoes" className="hover:text-coral-300 transition-colors">Ações Sociais</a>
            <a href="#pascoa" className="hover:text-coral-300 transition-colors">Páscoa das Crianças</a>
          </div>

          <div className="mt-10 h-px w-full max-w-md bg-white/10" />

          <p className="mt-6 text-xs text-primary-400">
            © {new Date().getFullYear()} Projeto Amor de Cristo. Feito com amor e
            por amor.
          </p>
        </div>
      </div>
    </footer>
  );
}
