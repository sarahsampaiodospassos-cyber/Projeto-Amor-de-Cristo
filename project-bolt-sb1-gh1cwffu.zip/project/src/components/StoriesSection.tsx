import { Quote } from 'lucide-react';
import { stories } from '@/data/content';
import { useReveal } from '@/hooks/useReveal';

export function StoriesSection() {
  const { ref, inView } = useReveal();

  return (
    <section id="historias" className="bg-white py-20 lg:py-32">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div
          ref={ref}
          className={`reveal ${inView ? 'in-view' : ''} mx-auto max-w-2xl text-center`}
        >
          <span className="text-sm font-semibold uppercase tracking-wider text-coral-600">
            Vidas Transformadas
          </span>
          <h2 className="mt-3 font-heading text-[2rem] font-bold text-primary-900 sm:text-4xl">
            Histórias que o amor escreveu
          </h2>
          <p className="mt-4 text-base leading-relaxed text-primary-700 sm:mt-5 sm:text-lg">
            Cada casa erguida, cada cesta entregue e cada gesto de carinho
            carrega uma história. Conheça algumas das vidas que foram tocadas pelo
            projeto.
          </p>
        </div>

        <div className="mt-10 grid gap-6 sm:mt-16 sm:grid-cols-2 lg:grid-cols-3 lg:gap-8">
          {stories.map((s, i) => (
            <StoryCard key={s.id} story={s} index={i} />
          ))}
        </div>

        <p className="mt-12 text-center text-sm text-primary-500">
          Em breve, mais histórias serão adicionadas. Se você foi impactado pelo
          projeto e quer contar sua história, nos escreva na seção de Cartas.
        </p>
      </div>
    </section>
  );
}

function StoryCard({
  story,
  index,
}: {
  story: (typeof stories)[number];
  index: number;
}) {
  const { ref, inView } = useReveal();

  return (
    <article
      ref={ref}
      className={`reveal ${inView ? 'in-view' : ''} group overflow-hidden rounded-2xl bg-sand-50 shadow-lg shadow-primary-900/5 transition-all duration-300 hover:-translate-y-2 hover:shadow-xl hover:shadow-primary-900/10`}
      style={{ animationDelay: `${index * 120}ms` }}
    >
      <div className="relative h-48 overflow-hidden sm:h-56">
        <img
          src={story.image}
          alt={story.title}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <span className="absolute left-4 top-4 rounded-full bg-coral-500 px-3 py-1 text-xs font-semibold text-white shadow-lg">
          {story.tag}
        </span>
      </div>
      <div className="p-5 sm:p-6">
        <Quote className="h-7 w-7 text-coral-300" />
        <h3 className="mt-2 font-heading text-lg font-bold text-primary-900 sm:mt-3 sm:text-xl">
          {story.title}
        </h3>
        <p className="mt-2 text-sm leading-relaxed text-primary-600 sm:mt-3">{story.excerpt}</p>
        <p className="mt-4 text-sm font-semibold text-coral-600">— {story.name}</p>
      </div>
    </article>
  );
}
