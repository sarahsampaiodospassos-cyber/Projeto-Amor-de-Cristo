import { useEffect, useState } from 'react';
import { Menu, X } from 'lucide-react';

const links = [
  { href: '#inicio', label: 'Início' },
  { href: '#historia', label: 'Nossa História' },
  { href: '#doar', label: 'Doações' },
  { href: '#cartas', label: 'Cartas & Orações' },
  { href: '#historias', label: 'Vidas Transformadas' },
  { href: '#acoes', label: 'Ações Sociais' },
  { href: '#pascoa', label: 'Páscoa das Crianças' },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 z-50 w-full transition-all duration-300 ${
        scrolled
          ? 'bg-primary-900/95 backdrop-blur-md shadow-lg shadow-primary-950/20'
          : 'bg-transparent'
      }`}
    >
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 lg:px-8">
        <a href="#inicio" className="flex shrink-0 items-center" aria-label="Projeto Amor de Cristo">
          <span className="flex h-12 w-[4.5rem] items-center justify-center overflow-hidden rounded-xl bg-white px-1 shadow-lg shadow-primary-950/20 sm:h-14 sm:w-20">
            <img
              src="/image.png"
              alt="Projeto Amor de Cristo — Organização Social"
              className="h-full w-full object-contain"
            />
          </span>
        </a>

        <ul className="hidden items-center gap-1 lg:flex">
          {links.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                className="rounded-full px-3.5 py-2 text-sm font-medium text-primary-100 transition-colors hover:bg-white/10 hover:text-white"
              >
                {l.label}
              </a>
            </li>
          ))}
        </ul>

        <a
          href="#doar"
          className="hidden rounded-full bg-coral-500 px-5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-coral-600/30 transition-all hover:bg-coral-600 hover:shadow-coral-600/40 lg:inline-block"
        >
          Quero Doar
        </a>

        <button
          className="text-white lg:hidden"
          onClick={() => setOpen(!open)}
          aria-label="Menu"
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </nav>

      {open && (
        <div className="border-t border-white/10 bg-primary-900/98 backdrop-blur-md lg:hidden">
          <ul className="space-y-1 px-5 py-4">
            {links.map((l) => (
              <li key={l.href}>
                <a
                  href={l.href}
                  onClick={() => setOpen(false)}
                  className="block rounded-lg px-4 py-3 text-sm font-medium text-primary-100 hover:bg-white/10 hover:text-white"
                >
                  {l.label}
                </a>
              </li>
            ))}
            <li>
              <a
                href="#doar"
                onClick={() => setOpen(false)}
                className="mt-2 block rounded-lg bg-coral-500 px-4 py-3 text-center text-sm font-semibold text-white"
              >
                Quero Doar
              </a>
            </li>
          </ul>
        </div>
      )}
    </header>
  );
}
