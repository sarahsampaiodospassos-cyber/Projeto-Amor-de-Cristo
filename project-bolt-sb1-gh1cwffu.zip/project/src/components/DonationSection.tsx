import { useState } from 'react';
import {
  Heart,
  Gift,
  Home,
  Sparkles,
  Check,
  X,
  Copy,
  CheckCheck,
  QrCode,
} from 'lucide-react';
import { useReveal } from '@/hooks/useReveal';

const PIX_KEY = '57.030.657/0001-19';

const presets = [
  { amount: 25, icon: Gift, label: 'Cesta básica', desc: 'Alimenta uma família por uma semana' },
  { amount: 50, icon: Sparkles, label: 'Kit Páscoa', desc: 'Leva alegria a 5 crianças' },
  { amount: 100, icon: Home, label: 'Material de construção', desc: 'Ajuda a erguer uma casa' },
  { amount: 250, icon: Heart, label: 'Ação social completa', desc: 'Patrocina uma oficina por um mês' },
];

type PaymentView = 'options' | 'copy' | 'qr';

export function DonationSection() {
  const { ref, inView } = useReveal();
  const [selected, setSelected] = useState<number | null>(50);
  const [modalOpen, setModalOpen] = useState(false);
  const [paymentView, setPaymentView] = useState<PaymentView>('options');
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(PIX_KEY);
    } catch {
      const textarea = document.createElement('textarea');
      textarea.value = PIX_KEY;
      textarea.style.position = 'fixed';
      textarea.style.opacity = '0';
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  return (
    <section id="doar" className="relative overflow-hidden bg-primary-900 py-20 lg:py-32">
      <div className="absolute inset-0 bg-gradient-to-br from-primary-900 via-primary-950 to-primary-900" />
      <div className="absolute -right-24 -top-24 h-96 w-96 rounded-full bg-coral-500/10 blur-3xl" />
      <div className="absolute -bottom-24 -left-24 h-96 w-96 rounded-full bg-primary-400/10 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <div
          ref={ref}
          className={`reveal ${inView ? 'in-view' : ''} mx-auto max-w-2xl text-center`}
        >
          <span className="inline-flex items-center gap-2 rounded-full border border-coral-400/30 bg-coral-500/10 px-4 py-1.5 text-sm font-medium text-coral-300">
            <Heart className="h-4 w-4" fill="currentColor" />
            Faça sua doação
          </span>
          <h2 className="mt-5 font-heading text-[2rem] font-bold text-white sm:text-4xl lg:text-5xl text-balance">
            Sua doação se transforma em amor concreto
          </h2>
          <p className="mt-4 text-base leading-relaxed text-primary-200 sm:mt-5 sm:text-lg">
            Cada valor faz diferença. Escolha abaixo quanto deseja contribuir e
            pague via PIX com QR Code ou copiando a chave.
          </p>
        </div>

        <div className="mt-10 grid gap-4 sm:mt-12 sm:grid-cols-2 sm:gap-5 lg:grid-cols-4">
          {presets.map((p, i) => {
            const Icon = p.icon;
            const active = selected === p.amount;
            return (
              <button
                key={p.amount}
                onClick={() => setSelected(p.amount)}
                className={`group relative overflow-hidden rounded-2xl border p-5 text-left transition-all duration-300 sm:p-6 ${
                  active
                    ? 'border-coral-400 bg-coral-500/15 scale-105'
                    : 'border-white/10 bg-white/5 hover:border-white/20 hover:bg-white/10'
                }`}
                style={{ animationDelay: `${i * 80}ms` }}
              >
                {active && (
                  <span className="absolute right-4 top-4 flex h-6 w-6 items-center justify-center rounded-full bg-coral-500 text-white">
                    <Check className="h-3.5 w-3.5" />
                  </span>
                )}
                <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-xl bg-coral-500/20 text-coral-300 transition-colors group-hover:bg-coral-500/30 sm:mb-4 sm:h-12 sm:w-12">
                  <Icon className="h-6 w-6" />
                </div>
                <div className="font-heading text-2xl font-extrabold text-white sm:text-3xl">
                  R$ <span className="text-coral-400">{p.amount}</span>
                </div>
                <div className="mt-2 text-sm font-semibold text-primary-100">
                  {p.label}
                </div>
                <div className="mt-1 text-xs text-primary-300">{p.desc}</div>
              </button>
            );
          })}
        </div>

        <div className="mx-auto mt-8 max-w-md sm:mt-10">
          <label className="block text-sm font-medium text-primary-200">
            Ou digite outro valor
          </label>
          <div className="mt-2 flex items-center gap-3 rounded-full border border-white/15 bg-white/5 px-5 py-1.5 focus-within:border-coral-400">
            <span className="text-lg font-semibold text-primary-300">R$</span>
            <input
              type="number"
              min={1}
              placeholder="Digite o valor"
              onChange={(e) =>
                setSelected(e.target.value ? Number(e.target.value) : null)
              }
              className="w-full bg-transparent py-2 text-lg font-semibold text-white placeholder:text-primary-400 focus:outline-none"
            />
          </div>
        </div>

        <div className="mx-auto mt-8 max-w-md text-center sm:mt-10">
          <button
            onClick={() => {
              setPaymentView('options');
              setModalOpen(true);
            }}
            className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-coral-500 px-8 py-4 text-base font-bold text-white shadow-xl shadow-coral-600/30 transition-all hover:scale-105 hover:bg-coral-600"
          >
            <QrCode className="h-5 w-5" />
            Doar R$ {selected ?? '—'} via PIX
          </button>
          <p className="mt-4 text-xs text-primary-300">
            Pagamento via PIX. Escolha entre copiar a chave ou visualizar o QR
            Code.
          </p>
        </div>
      </div>

      {modalOpen && (
        <PixModal
          amount={selected}
          onClose={() => setModalOpen(false)}
          onCopy={handleCopy}
          copied={copied}
          paymentView={paymentView}
          onSelectView={setPaymentView}
        />
      )}
    </section>
  );
}

function PixModal({
  amount,
  onClose,
  onCopy,
  copied,
  paymentView,
  onSelectView,
}: {
  amount: number | null;
  onClose: () => void;
  onCopy: () => void;
  copied: boolean;
  paymentView: PaymentView;
  onSelectView: (view: PaymentView) => void;
}) {
  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 animate-fade-in bg-primary-950/80 backdrop-blur-sm" />

      <div
        className="relative max-h-[90vh] w-full max-w-md overflow-y-auto rounded-3xl bg-white shadow-2xl animate-fade-up"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute right-4 top-4 z-10 flex h-9 w-9 items-center justify-center rounded-full bg-primary-50 text-primary-600 transition-colors hover:bg-primary-100"
          aria-label="Fechar"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="bg-gradient-to-br from-primary-900 to-primary-950 px-5 py-6 text-center sm:px-6 sm:py-7">
          <h3 className="font-heading text-xl font-bold text-white">Doação via PIX</h3>
          {amount != null && (
            <p className="mt-1 text-sm text-primary-200">
              Valor selecionado: <span className="font-bold text-coral-400">R$ {amount}</span>
            </p>
          )}
        </div>

        <div className="p-5 sm:p-6">
          <div className="grid gap-3 sm:grid-cols-2">
            <PaymentOption
              active={paymentView === 'copy'}
              icon={<Copy className="h-5 w-5" />}
              title="Copiar e colar"
              description="Copie a chave CNPJ"
              onClick={() => onSelectView('copy')}
            />
            <PaymentOption
              active={paymentView === 'qr'}
              icon={<QrCode className="h-5 w-5" />}
              title="QR Code"
              description="Visualize o código"
              onClick={() => onSelectView('qr')}
            />
          </div>

          {paymentView === 'options' && (
            <div className="mt-6 rounded-2xl bg-primary-50 p-5 text-center">
              <p className="font-heading text-lg font-bold text-primary-900">
                Escolha uma forma de doar
              </p>
              <p className="mt-2 text-sm leading-relaxed text-primary-600">
                Selecione uma das opções acima para continuar com sua doação via PIX.
              </p>
            </div>
          )}

          {paymentView === 'copy' && (
            <div className="mt-6">
              <p className="mb-2 text-center text-sm font-medium text-primary-700">
                Copie e cole a chave PIX no aplicativo do seu banco:
              </p>
              <div className="flex flex-col items-stretch gap-2 sm:flex-row sm:items-stretch">
                <div className="flex flex-1 items-center justify-center rounded-xl border border-primary-200 bg-sand-50 px-4 py-3 sm:py-0">
                  <span className="break-all text-center font-mono text-sm font-semibold tracking-wide text-primary-900 sm:text-left">
                    {PIX_KEY}
                  </span>
                </div>
                <button
                  onClick={onCopy}
                  className={`inline-flex shrink-0 items-center justify-center gap-2 rounded-xl px-5 py-3 text-sm font-bold transition-all ${
                    copied ? 'bg-green-500 text-white' : 'bg-coral-500 text-white hover:bg-coral-600'
                  }`}
                >
                  {copied ? (
                    <><CheckCheck className="h-4 w-4" />Copiado!</>
                  ) : (
                    <><Copy className="h-4 w-4" />Copiar</>
                  )}
                </button>
              </div>
              <p className="mt-3 text-center text-xs text-primary-400">
                Chave CNPJ do Projeto Amor de Cristo
              </p>
            </div>
          )}

          {paymentView === 'qr' && (
            <div className="mt-6 text-center">
              <div className="relative mx-auto w-fit rounded-2xl border-2 border-primary-100 bg-white p-4 shadow-lg">
                <QrPlaceholder />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-white shadow-md">
                    <Heart className="h-6 w-6 text-coral-500" fill="currentColor" />
                  </div>
                </div>
              </div>
              <p className="mt-3 text-xs font-medium text-primary-500">
                QR Code ilustrativo — será substituído pelo código PIX oficial.
              </p>
            </div>
          )}

          <div className="mt-6 rounded-2xl bg-primary-50 p-4 text-center">
            <p className="text-sm text-primary-600">
              Após realizar o pagamento, sua doação estará confirmada. Se quiser,
              envie uma carta na seção de Cartas & Orações para nos contar!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function PaymentOption({
  active,
  icon,
  title,
  description,
  onClick,
}: {
  active: boolean;
  icon: React.ReactNode;
  title: string;
  description: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-3 rounded-2xl border p-4 text-left transition-all ${
        active
          ? 'border-coral-400 bg-coral-500/10 text-primary-900'
          : 'border-primary-100 bg-sand-50 text-primary-700 hover:border-primary-200'
      }`}
    >
      <span className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${active ? 'bg-coral-500 text-white' : 'bg-primary-100 text-primary-600'}`}>
        {icon}
      </span>
      <span>
        <span className="block text-sm font-bold">{title}</span>
        <span className="mt-0.5 block text-xs text-primary-500">{description}</span>
      </span>
    </button>
  );
}

function QrPlaceholder() {
  const cells = [
    1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1,
    1, 0, 0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1,
    1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 0, 1, 0, 1, 1,
    0, 1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 0,
    1, 0, 1, 1, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0, 1, 1, 0, 0, 1, 0, 1,
    1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1,
    0, 1, 1, 0, 0, 1, 0, 0, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1, 0,
    1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1,
    1, 1, 0, 0, 1, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 1,
    0, 1, 1, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 0, 1, 0,
    1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 1,
    1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1,
    0, 1, 0, 1, 0, 0, 1, 1, 0, 1, 1, 0, 0, 1, 0, 1, 0, 1, 0, 0, 1,
    1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1,
    0, 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1, 1, 0,
    1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 0, 1, 1,
    0, 0, 1, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 1, 0, 0, 1, 1, 0, 0,
    1, 1, 0, 1, 1, 1, 0, 0, 1, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 1, 1,
    0, 1, 1, 0, 0, 1, 1, 1, 0, 0, 1, 0, 0, 1, 1, 1, 0, 0, 1, 0, 1,
    1, 0, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1, 0,
    1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 1, 0, 1,
  ];
  const size = 21;

  return (
    <svg width={168} height={168} viewBox={`0 0 ${size} ${size}`} className="block">
      {cells.map((cell, index) => {
        if (!cell) return null;
        const x = index % size;
        const y = Math.floor(index / size);
        return <rect key={index} x={x} y={y} width={1} height={1} rx={0.15} fill="#155760" />;
      })}
    </svg>
  );
}
