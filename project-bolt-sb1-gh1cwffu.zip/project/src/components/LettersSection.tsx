import { useState } from 'react';
import { Heart, MessageSquare, Sparkles, Send, CheckCircle2, Loader2 } from 'lucide-react';
import { supabase, type LetterType } from '@/lib/supabase';
import { useReveal } from '@/hooks/useReveal';

const types: { value: LetterType; label: string; icon: typeof Heart; desc: string }[] = [
  {
    value: 'help',
    label: 'Pedido de Ajuda',
    icon: MessageSquare,
    desc: 'Conte sua necessidade. Estamos aqui para ouvir.',
  },
  {
    value: 'motivation',
    label: 'Carta de Motivação',
    icon: Sparkles,
    desc: 'Compartilhe palavras que edificam e animam.',
  },
  {
    value: 'prayer',
    label: 'Pedido de Oração',
    icon: Heart,
    desc: 'Deixe seu pedido. Oremos juntos por você.',
  },
];

export function LettersSection() {
  const { ref, inView } = useReveal();
  const [type, setType] = useState<LetterType>('prayer');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [status, setStatus] = useState<'idle' | 'sending' | 'sent' | 'error'>('idle');
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedName = name.trim();
    const trimmedEmail = email.trim();
    const trimmedMessage = message.trim();

    if (trimmedName.length < 2) {
      setStatus('error');
      setErrorMsg('Informe seu nome para enviar a carta.');
      return;
    }

    if (trimmedMessage.length < 10) {
      setStatus('error');
      setErrorMsg('Escreva uma mensagem com pelo menos 10 caracteres.');
      return;
    }

    setStatus('sending');
    setErrorMsg('');

    const { error: saveError } = await supabase.from('prayer_letters').insert({
      name: trimmedName,
      email: trimmedEmail || null,
      letter_type: type,
      message: trimmedMessage,
    });

    if (saveError) {
      setStatus('error');
      setErrorMsg('Não foi possível enviar agora. Tente novamente em instantes.');
      return;
    }

    const { data: emailResult, error: emailError } = await supabase.functions.invoke(
      'send-prayer-letter',
      {
        body: {
          type,
          name: trimmedName,
          email: trimmedEmail,
          message: trimmedMessage,
        },
      },
    );

    if (emailError || emailResult?.message !== 'Carta enviada com sucesso.') {
      setStatus('error');
      setErrorMsg('A carta foi registrada, mas o e-mail não pôde ser enviado. Tente novamente mais tarde.');
      return;
    }

    setStatus('sent');
    setName('');
    setEmail('');
    setMessage('');
    setTimeout(() => setStatus('idle'), 6000);
  };

  return (
    <section id="cartas" className="bg-sand-50 py-20 lg:py-32">
      <div className="mx-auto max-w-5xl px-5 lg:px-8">
        <div
          ref={ref}
          className={`reveal ${inView ? 'in-view' : ''} mx-auto max-w-2xl text-center`}
        >
          <span className="text-sm font-semibold uppercase tracking-wider text-coral-600">
            Cartas & Orações
          </span>
          <h2 className="mt-3 font-heading text-[2rem] font-bold text-primary-900 sm:text-4xl">
            Um espaço para se expressar e ser ouvido
          </h2>
          <p className="mt-4 text-base leading-relaxed text-primary-700 sm:mt-5 sm:text-lg">
            Envie um pedido de ajuda, uma carta de motivação ou um pedido de
            oração. Tudo que chega aqui é acolhido com respeito e fé.
          </p>
        </div>

        <div className="mt-10 overflow-hidden rounded-3xl bg-white shadow-xl shadow-primary-900/5 sm:mt-12">
          <div className="grid lg:grid-cols-[1fr_1.5fr]">
            {/* Type selector */}
            <div className="space-y-3 bg-primary-900 p-5 sm:p-6 lg:p-8">
              <h3 className="font-heading text-lg font-bold text-white">
                Escolha o tipo de carta
              </h3>
              {types.map((t) => {
                const Icon = t.icon;
                const active = type === t.value;
                return (
                  <button
                    key={t.value}
                    onClick={() => setType(t.value)}
                    className={`flex w-full items-start gap-3 rounded-2xl border p-4 text-left transition-all ${
                      active
                        ? 'border-coral-400 bg-coral-500/15'
                        : 'border-white/10 bg-white/5 hover:bg-white/10'
                    }`}
                  >
                    <span
                      className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${
                        active ? 'bg-coral-500 text-white' : 'bg-white/10 text-primary-200'
                      }`}
                    >
                      <Icon className="h-5 w-5" />
                    </span>
                    <span>
                      <span className="block text-sm font-semibold text-white">
                        {t.label}
                      </span>
                      <span className="mt-0.5 block text-xs text-primary-300">
                        {t.desc}
                      </span>
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="p-5 sm:p-6 lg:p-8">
              {status === 'sent' ? (
                <div className="flex h-full flex-col items-center justify-center text-center py-12">
                  <CheckCircle2 className="h-16 w-16 text-green-500 animate-fade-in" />
                  <h3 className="mt-5 font-heading text-2xl font-bold text-primary-900">
                    Carta enviada com sucesso!
                  </h3>
                  <p className="mt-3 text-primary-600">
                    Recebemos sua mensagem com carinho. Obrigado por confiar no
                    Projeto Amor de Cristo.
                  </p>
                </div>
              ) : (
                <>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <Field label="Seu nome" required>
                      <input
                        type="text"
                        required
                        minLength={2}
                        maxLength={100}
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Como podemos te chamar?"
                        className="w-full rounded-xl border border-primary-200 bg-sand-50 px-4 py-3 text-primary-900 placeholder:text-primary-400 focus:border-coral-400 focus:outline-none focus:ring-2 focus:ring-coral-400/20"
                      />
                    </Field>
                    <Field label="E-mail (opcional)">
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="seu@email.com"
                        className="w-full rounded-xl border border-primary-200 bg-sand-50 px-4 py-3 text-primary-900 placeholder:text-primary-400 focus:border-coral-400 focus:outline-none focus:ring-2 focus:ring-coral-400/20"
                      />
                    </Field>
                  </div>

                  <div className="mt-4">
                    <Field label="Sua mensagem" required>
                      <textarea
                        required
                        minLength={10}
                        maxLength={3000}
                        rows={6}
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        placeholder="Escreva aqui o que está no seu coração..."
                        className="w-full resize-none rounded-xl border border-primary-200 bg-sand-50 px-4 py-3 text-primary-900 placeholder:text-primary-400 focus:border-coral-400 focus:outline-none focus:ring-2 focus:ring-coral-400/20"
                      />
                    </Field>
                    <p className="mt-1 text-right text-xs text-primary-400">
                      {message.length}/3000
                    </p>
                  </div>

                  {status === 'error' && (
                    <p className="mt-4 rounded-xl bg-red-50 px-4 py-3 text-sm text-red-600">
                      {errorMsg}
                    </p>
                  )}

                  <button
                    type="submit"
                    disabled={status === 'sending'}
                    className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-full bg-coral-500 px-6 py-3.5 text-base font-bold text-white shadow-lg shadow-coral-600/20 transition-all hover:bg-coral-600 disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    {status === 'sending' ? (
                      <>
                        <Loader2 className="h-5 w-5 animate-spin" />
                        Enviando...
                      </>
                    ) : (
                      <>
                        <Send className="h-5 w-5" />
                        Enviar carta
                      </>
                    )}
                  </button>
                </>
              )}
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}

function Field({
  label,
  required,
  children,
}: {
  label: string;
  required?: boolean;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-medium text-primary-700">
        {label} {required && <span className="text-coral-500">*</span>}
      </span>
      {children}
    </label>
  );
}
