import { useReveal } from '@/hooks/useReveal';

export function EasterSection() {
  const { ref, inView } = useReveal();

  return (
    <section id="pascoa" className="relative overflow-hidden bg-primary-950 py-20 lg:py-32">
      <div className="absolute inset-0">
        <img
          src="https://images.pexels.com/photos/9090750/pexels-photo-9090750.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
          alt="Crianças receiving food supplies"
          className="h-full w-full object-cover opacity-20"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-primary-950 via-primary-950/90 to-primary-900/50" />
      </div>

      <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <div className="grid items-center gap-10 lg:grid-cols-2 lg:gap-12">
          <div
            ref={ref}
            className={`reveal ${inView ? 'in-view' : ''}`}
          >
            <span className="text-sm font-semibold uppercase tracking-wider text-coral-400">
              Ação Especial
            </span>
            <h2 className="mt-3 font-heading text-[2rem] font-bold text-white sm:text-4xl lg:text-5xl text-balance">
              Páscoa das Crianças
            </h2>
            <p className="mt-4 text-base leading-relaxed text-primary-200 sm:mt-5 sm:text-lg">
              Uma data que significa renovação e esperança. No Projeto Amor de
              Cristo, a Páscoa ganha um significado ainda mais especial: é o dia
              em que levamos alegria, brinquedos e chocolates para centenas de
              crianças da nossa comunidade.
            </p>
            <p className="mt-4 text-base leading-relaxed text-primary-200 sm:text-lg">
              Mais do que presentear, criamos um dia de festa — com brincadeiras,
              música, lanche e muito amor. Cada sorriso é a prova de que pequenos
              gestos podem marcar para sempre a memória de uma criança.
            </p>

            <div className="mt-8 flex flex-wrap gap-3">
              <Badge>Brinquedos doados</Badge>
              <Badge>Chocolates distribuídos</Badge>
              <Badge>Dia de festa completo</Badge>
              <Badge>Voluntários envolvidos</Badge>
            </div>

            <a
              href="#doar"
              className="mt-8 inline-flex items-center gap-2 rounded-full bg-coral-500 px-7 py-3.5 text-base font-bold text-white shadow-xl shadow-coral-600/30 transition-all hover:bg-coral-600 hover:scale-105"
            >
              Apoiar a Páscoa das Crianças
            </a>
          </div>

          <div className="relative mt-6 lg:mt-0">
            <div className="overflow-hidden rounded-3xl shadow-2xl shadow-primary-950/50">
              <img
                src="https://images.pexels.com/photos/6472413/pexels-photo-6472413.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                alt="Crianças e voluntários em atividade comunitária"
                className="h-full w-full object-cover"
              />
            </div>
            <div className="absolute -bottom-5 left-4 rounded-2xl bg-coral-500 px-5 py-3 shadow-xl sm:-left-6 sm:px-6 sm:py-4">
              <div className="font-heading text-3xl font-extrabold text-white">
                +400
              </div>
              <div className="text-xs font-medium text-coral-100">
                crianças atendidas em 2025
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Badge({ children }: { children: React.ReactNode }) {
  return (
    <span className="rounded-full border border-white/15 bg-white/5 px-4 py-2 text-sm font-medium text-primary-100">
      {children}
    </span>
  );
}
