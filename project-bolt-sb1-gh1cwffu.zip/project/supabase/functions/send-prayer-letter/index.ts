const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const letterTypeLabels: Record<string, string> = {
  help: "Pedido de Ajuda",
  motivation: "Carta de Motivação",
  prayer: "Pedido de Oração",
};

const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function jsonResponse(body: Record<string, string>, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

function escapeHtml(value: string) {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  if (req.method !== "POST") {
    return jsonResponse({ error: "Método não permitido." }, 405);
  }

  try {
    const body = await req.json();
    const name = typeof body.name === "string" ? body.name.trim() : "";
    const message = typeof body.message === "string" ? body.message.trim() : "";
    const type = typeof body.type === "string" ? body.type : "";
    const email = typeof body.email === "string" ? body.email.trim() : "";
    const typeLabel = letterTypeLabels[type];

    if (!typeLabel || name.length < 2 || name.length > 100 || message.length < 10 || message.length > 3000) {
      return jsonResponse({ error: "Confira os dados obrigatórios da carta." }, 400);
    }

    if (email && (email.length > 254 || !emailPattern.test(email))) {
      return jsonResponse({ error: "Confira o endereço de e-mail informado." }, 400);
    }

    const resendApiKey = Deno.env.get("RESEND_API_KEY");
    if (!resendApiKey) {
      return jsonResponse({ error: "O serviço de e-mail ainda não está disponível." }, 503);
    }

    const safeName = escapeHtml(name);
    const safeEmail = escapeHtml(email || "Não informado");
    const safeMessage = escapeHtml(message).replaceAll("\n", "<br />");
    const subject = `Nova mensagem recebida: ${typeLabel}`;
    const from = Deno.env.get("RESEND_FROM_EMAIL") || "Projeto Amor de Cristo <onboarding@resend.dev>";

    const resendResponse = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${resendApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from,
        to: ["sarahsampaiodospassos@gmail.com"],
        subject,
        ...(email ? { reply_to: email } : {}),
        html: `
          <h2>${escapeHtml(subject)}</h2>
          <p><strong>Nome:</strong> ${safeName}</p>
          <p><strong>E-mail:</strong> ${safeEmail}</p>
          <p><strong>Tipo:</strong> ${escapeHtml(typeLabel)}</p>
          <p><strong>Mensagem:</strong></p>
          <p>${safeMessage}</p>
        `,
        text: `${subject}\n\nNome: ${name}\nE-mail: ${email || "Não informado"}\nTipo: ${typeLabel}\n\nMensagem:\n${message}`,
      }),
    });

    if (!resendResponse.ok) {
      return jsonResponse({ error: "Não foi possível concluir o envio da carta." }, 502);
    }

    return jsonResponse({ message: "Carta enviada com sucesso." });
  } catch {
    return jsonResponse({ error: "Não foi possível processar a carta agora." }, 500);
  }
});
