/*
# Create prayer letters inbox

1. New Tables
- `prayer_letters` stores messages of help, motivation, and prayer submitted through the public website.
- `id` uniquely identifies each letter.
- `name` stores the sender's display name.
- `email` optionally stores a reply address.
- `letter_type` identifies help, motivation, or prayer requests.
- `message` stores the letter content.
- `created_at` records when the message was submitted.
2. Security
- Row level security is enabled.
- Anonymous and authenticated visitors may submit letters and the project may read them through its public-key client.
- The four CRUD permissions are declared separately for predictable access control.
3. Important Notes
- This is a single-tenant public project without sign-in.
- No authentication or personal user ownership is introduced by this migration.
*/

CREATE TABLE IF NOT EXISTS public.prayer_letters (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL CHECK (char_length(name) BETWEEN 2 AND 100),
  email text,
  letter_type text NOT NULL CHECK (letter_type IN ('help', 'motivation', 'prayer')),
  message text NOT NULL CHECK (char_length(message) BETWEEN 10 AND 3000),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.prayer_letters ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Public can read prayer letters" ON public.prayer_letters;
CREATE POLICY "Public can read prayer letters" ON public.prayer_letters
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "Public can send prayer letters" ON public.prayer_letters;
CREATE POLICY "Public can send prayer letters" ON public.prayer_letters
  FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "Public can update prayer letters" ON public.prayer_letters;
CREATE POLICY "Public can update prayer letters" ON public.prayer_letters
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Public can delete prayer letters" ON public.prayer_letters;
CREATE POLICY "Public can delete prayer letters" ON public.prayer_letters
  FOR DELETE TO anon, authenticated USING (true);
